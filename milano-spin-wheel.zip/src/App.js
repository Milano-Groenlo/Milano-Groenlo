
// Milano Spin Wheel App (v1.6 - Critical fix for slice error with fallback data)

import React, { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Papa from "papaparse";
import { Wheel } from "react-custom-roulette";

export default function SpinWheelApp() {
  const [orderNumbers, setOrderNumbers] = useState([]);
  const [winner, setWinner] = useState(null);
  const [logo, setLogo] = useState(null);
  const [music, setMusic] = useState(null);
  const [mustSpin, setMustSpin] = useState(false);
  const [prizeNumber, setPrizeNumber] = useState(0);
  const audioRef = useRef(null);

  const handleCSVUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          const data = Array.isArray(results.data) ? results.data : [];
          const ids = data
            .map((row) => {
              if (!row || typeof row !== 'object') return null;
              const raw = row.id || row.order_id;
              return raw != null ? String(raw).trim() : null;
            })
            .filter((id) => id && id.length > 0);

          const unique = [...new Set(ids)];
          const formatted = unique.map((id) => ({ option: id }));

          setOrderNumbers(formatted);
        } catch (error) {
          console.error("CSV parsing error:", error);
          setOrderNumbers([]);
        }
      },
      error: (error) => {
        console.error("PapaParse error:", error);
        setOrderNumbers([]);
      },
    });
  };

  const handleSpin = () => {
    if (!Array.isArray(orderNumbers) || orderNumbers.length === 0) return;
    const randomIndex = Math.floor(Math.random() * orderNumbers.length);
    setPrizeNumber(randomIndex);
    setWinner(null);
    setMustSpin(true);

    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(() => {});
    }
  };

  const handleStopSpinning = () => {
    if (Array.isArray(orderNumbers) && orderNumbers[prizeNumber]) {
      setWinner(orderNumbers[prizeNumber].option);
    }
    setMustSpin(false);

    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-6">Milano Restaurant Spin Wheel</h1>

      <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
        <Card>
          <CardContent className="p-4">
            <label className="block mb-2 font-semibold">Upload CSV File</label>
            <input type="file" accept=".csv" onChange={handleCSVUpload} className="mb-4" />

            <label className="block mb-2 font-semibold">Upload Logo</label>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => setLogo(URL.createObjectURL(e.target.files?.[0]))}
              className="mb-4"
            />

            <label className="block mb-2 font-semibold">Upload Music</label>
            <input
              type="file"
              accept="audio/*"
              onChange={(e) => setMusic(URL.createObjectURL(e.target.files?.[0]))}
              className="mb-4"
            />

            <Button
              onClick={handleSpin}
              disabled={!Array.isArray(orderNumbers) || orderNumbers.length === 0 || mustSpin}
              className="w-full"
            >
              🎯 Spin the Wheel
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex flex-col items-center">
            {logo && <img src={logo} alt="Milano Logo" className="w-24 mb-4" />}
            <div className="w-full h-[300px]">
              <Wheel
                mustStartSpinning={mustSpin}
                prizeNumber={prizeNumber}
                data={Array.isArray(orderNumbers) ? orderNumbers : []}
                backgroundColors={["#ff4d4d", "#ffffff", "#008000"]}
                textColors={["#000"]}
                onStopSpinning={handleStopSpinning}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {winner && (
        <div className="mt-6 p-4 bg-green-100 border border-green-400 rounded text-center">
          🎉 <strong>Congratulations!</strong> Order number <strong>{winner}</strong> has won a free meal worth €50! We will contact you soon.
        </div>
      )}

      {music && <audio ref={audioRef} src={music} />} 
    </div>
  );
}
